var tower,towerImage;
var door,doorImage;
var doorGroup;
var climber, climberImage;
var climberGroup;
var ghost, ghostImage;
var invisibleGround;
var invisibleGroundGroup;
var gameState="play";
var score=0;

function preload(){
  towerImage=loadImage("tower.png");
  doorImage=loadImage("door.png");
  climberImage=loadImage("climber.png");
  ghostImage=loadImage("ghost-standing.png");
}

function setup(){
  createCanvas(600,600);
  tower=createSprite(300,300);
  tower.addImage("tower",towerImage);
  tower.velocityY=1;
  doorGroup=new Group();
  climberGroup=new Group();
  invisibleGroundGroup=new Group();
  ghost=createSprite(200,200,50,50);
  ghost.scale=0.3;
  ghost.addImage("ghost",ghostImage);
  
}

function draw(){
  background("black");
  if (gameState=="play"){
   
  if (tower.y>400){
    tower.y=300;
      }
  if (keyDown("left_arrow")){
    ghost.velocityX=-2;
  }
  if (keyDown("right_arrow")){
    ghost.velocityX=2;
  }
  if (keyDown("space")){
    ghost.velocityY=-2;
  }
  ghost.velocityY=ghost.velocityY+0.8;
  if (climberGroup.isTouching(ghost)){
      ghost.velocityY=0;
      }
  if (invisibleGroundGroup.isTouching(ghost)||ghost.y>600){
      gameState="end";
      ghost.destroy();
      score=score+1;
      }
  spawnDoors();
  drawSprites();
  textSize(40);
  fill("yellow");
  text("score: "+score,200,50);
}
if (gameState=="end"){
    textSize(20);
    fill("white");
    text("game over",250,300);
    }
}
function spawnDoors(){
  if (World.frameCount%240==0){
    var door=createSprite(200,-50);
    door.addImage("door",doorImage);
    door.x=Math.round(random(120,400));
    door.velocityY=1;
    door.lifetime=800;
    doorGroup.addGroup;
    var climber=createSprite(200,10);
    climber.addImage("climber",climberImage);
    var invisibleGround=createSprite(200,15);
    invisibleGround.width=climber.width;
    invisibleGround.height=2;
    climber.x=door.x;
    climber.velocityY=1;
    invisibleGround.x=door.x;
    invisibleGround.velocityY=1;
    climber.lifetime=800;
    climberGroup.addGroup;
    ghost.depth=door.depth;
    ghost.depth=ghost.depth+1;
    invisibleGround.debug=true;
    invisibleGroundGroup.add(invisibleGround);
  }
}